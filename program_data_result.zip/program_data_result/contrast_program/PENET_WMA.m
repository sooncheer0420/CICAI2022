%% PE-NET-WMA

%% initial
clear
clc

%% import data
for experiment=1:30
   clearvars -except experiment angleRMSE
data=xlsread('BMTdataset.xlsx');
datadouble=data(1:20,:);

Datasingleshape=datadouble(:,1:3);
Datasingleparameter=datadouble(:,4:end-1);
% DatasingleSA=datasingle(:,end);
DatasingleSA=datadouble(:,end);
% DataC=xlsread('dataTest3_C.xlsx');

DataNum=size(Datasingleshape,1);
%% dataset

radioTest=0.8;
numTest=round((1-radioTest)*DataNum);
idxtest = randperm(DataNum,numTest);

%test
TestSLinputS=Datasingleshape(idxtest,:);
TestSLinputP=Datasingleparameter(idxtest,:);
TestSLoutput=DatasingleSA(idxtest,:);
% TestC=DataC(idxtest,:);

%train
TrainSLinputS=Datasingleshape;
TrainSLinputP=Datasingleparameter;
TrainSLoutput=DatasingleSA;
% TrainC=DataC;


TrainSLinputS(idxtest,:)=[];
TrainSLinputP(idxtest,:)=[];
TrainSLoutput(idxtest,:)=[];
% TrainC(idxtest,:)=[];

%% Datastore




dsTrainA = arrayDatastore(TrainSLinputS);
dsTrainB = arrayDatastore(TrainSLinputP);
dsTrainC= arrayDatastore(TrainSLoutput);
% dsTrainC = arrayDatastore(TrainC);
dsTrain = combine(dsTrainA,dsTrainB,dsTrainC);


dsTestA = arrayDatastore(TestSLinputS);
dsTestB = arrayDatastore(TestSLinputP);
dsTestC = arrayDatastore(TestSLoutput);
% dsTestC = arrayDatastore(TestC);
dsTest = combine(dsTestA,dsTestB,dsTestC);


%% Define Deep Learning Model

numFeatures=size(TrainSLinputS,2);



layers = [
    featureInputLayer(3,'Name','featuresDLS')
    fullyConnectedLayer(10,'Name','mapping1')
    fullyConnectedLayer(2,'Name','SLS')
    concatenationLayer(1,2,'Name','concat')
    fullyConnectedLayer(10,'Name','fc2')
    fullyConnectedLayer(1,'Name','outSA')
    ];

lgraph1 = layerGraph(layers);

layers2 = featureInputLayer(11,'Name','parameter');

lgraph2 = addLayers(lgraph1,layers2);

lgraph2 = connectLayers(lgraph2,'parameter','concat/in2');


figure
plot(lgraph2)
% deepNetworkDesigner(lgraph)
dlnet2 = dlnetwork(lgraph2);





%% Define pretrained and pre-exploration sub-net





load('SPnet.mat','dlnet')
AW12=dlnet.Layers(2, 1).Weights;
AB12=dlnet.Layers(2, 1).Bias;
AW22=dlnet.Layers(3, 1).Weights;
AB22=dlnet.Layers(3, 1).Bias;

dlnet2 = replaceWeights4(dlnet2,5,AW12);
dlnet2 = replaceWeights4(dlnet2,6,AW22);
dlnet2 = replaceBias4(dlnet2,5,AB12);
dlnet2 = replaceBias4(dlnet2,6,AB22);

% load('ESNET.mat','net')
% ESW1=net.Layers(2, 1).Weights;
% ESB1=net.Layers(2, 1).Bias;
% ESW2=net.Layers(3, 1).Weights;
% ESB2=net.Layers(3, 1).Bias;
% 
% dlnet2 = replaceWeights4(dlnet2,2,ESW1);
% dlnet2 = replaceWeights4(dlnet2,3,ESW2);
% dlnet2 = replaceBias4(dlnet2,2,ESB1);
% dlnet2 = replaceBias4(dlnet2,3,ESB2);

%% Specify Training Options

numEpochs = 20;
miniBatchSize = 2;

plots = "training-progress";

learnRate = 0.01;
decay = 0.01;
momentum = 0.9;
%% Train Model

mbq = minibatchqueue(dsTrain,...
    'MiniBatchSize',miniBatchSize,...
    'MiniBatchFcn', @preprocessData,...
    'MiniBatchFormat',{'BC','BC',''});% (spatial, spatial, channel, batch)


if plots == "training-progress"
    figure
    lineLossTrain = animatedline('Color',[0.85 0.325 0.098]);
    ylim([0 inf])
    xlabel("Iteration")
    ylabel("Loss")
    grid on
end

%Initialize parameters for Adam.
trailingAvg = [];
trailingAvgSq = [];

%Train the model.
iteration = 0;
start = tic;

% Loop over epochs.

for epoch = 1:numEpochs
    
    % Shuffle data.
    shuffle(mbq)
    
    % Loop over mini-batches
    while hasdata(mbq)
        
        iteration = iteration + 1;
        
        [dlX1,dlX2,dlY1] = next(mbq);
                       
        % Evaluate the model gradients, state, and loss using dlfeval and the
        % modelGradients function.
        [gradients,state,loss] = dlfeval(@modelGradients, dlnet2,dlX1,dlX2,dlY1);
        dlnet2.State = state;
        
        % Update the network parameters using the Adam optimizer.
        [dlnet2,trailingAvg,trailingAvgSq] = adamupdate(dlnet2,gradients, ...
            trailingAvg,trailingAvgSq,iteration);
        
        % Display the training progress.
        if plots == "training-progress"
            D = duration(0,0,toc(start),'Format','hh:mm:ss');
            addpoints(lineLossTrain,iteration,double(gather(extractdata(loss))))
            title("Epoch: " + epoch + ", Elapsed: " + string(D))
            drawnow
        end
    end
end


%% Test Model


mbqTest = minibatchqueue(dsTest,...
    'MiniBatchSize',miniBatchSize,...
    'MiniBatchFcn', @preprocessData,...
    'MiniBatchFormat',{'BC','BC',''});

classesPredictions = [];
anglesPredictions = [];
classCorr = [];
angleDiff = [];
angleDiffper=[];
% Loop over mini-batches.
while hasdata(mbqTest)
    
    % Read mini-batch of data.
    [dlX1Test,dlX2Test,dlY1Test] = next(mbqTest);
    
    % Make predictions using the predict function.
    [dlY1Pred] = predict(dlnet2,dlX1Test,dlX2Test,'Outputs',"outSA");
    
    
 
    % Dermine predicted angles
    Y1PredBatch = extractdata(dlY1Pred);
    anglesPredictions = [anglesPredictions Y1PredBatch];
    
    % Compare predicted and true angles
    angleDiffBatch = Y1PredBatch - dlY1Test;
    angleDiff = [angleDiff extractdata(gather(angleDiffBatch))];   
    
     angleDiffBatchper = (Y1PredBatch - dlY1Test)./dlY1Test;
    angleDiffper = [angleDiffper extractdata(gather(angleDiffBatchper))]; 

    
end



angleRMSE(experiment) = sqrt(mean(angleDiff.^2));


anglediffper = mean(abs(angleDiffper));

save('result\PENETWMA','angleRMSE')

end





%% Model Gradients Function

function [gradients,state,loss] = modelGradients(dlnet,dlX1,dlX2,T1)

[dlY1,state] = forward(dlnet,dlX1,dlX2,'Outputs', "outSA");

lossAngles = mse(dlY1,T1);
% fc1weights=abs(dlnet.Layers(2, 1).Weights);
% L1fc1=sum(sum(fc1weights));
% loss =0.9*lossAngles+0.001*L1fc1;





DLshape=extractdata(dlX1); 
samplenum=size(DLshape,2);

% for iii=1:samplenum
%     NetPredictedShapeD(iii)=dlnet.Layers(3, 1).Weights(1,:)*(dlnet.Layers(2, 1).Weights*DLshape(:,iii)+dlnet.Layers(2, 1).Bias)+dlnet.Layers(3, 1).Bias(1);
%     NetPredictedShapeT(iii)=dlnet.Layers(3, 1).Weights(2,:)*(dlnet.Layers(2, 1).Weights*DLshape(:,iii)+dlnet.Layers(2, 1).Bias)+dlnet.Layers(3, 1).Bias(2);
%     [PhysiceShapeD(iii),PhysiceShapeT(iii)]=getPhysiceShape(DLshape(1,iii),DLshape(2,iii),DLshape(3,iii));
% %     physiceerrorD(samplenum)=abs(PhysiceShapeD-NetPredictedShapeD)/PhysiceShapeD;
% %     physiceerrorT(samplenum)=abs(PhysiceShapeT-NetPredictedShapeT)/PhysiceShapeT;
% end
% 
% % physiceerror=mean(physiceerrorD)+mean(physiceerrorT);
% physicalerror1=mse(NetPredictedShapeD,PhysiceShapeD);
% physicalerror2=mse(NetPredictedShapeT,PhysiceShapeT);






loss =lossAngles;
% loss =0.00001*lossAngles+physicalerror1+physicalerror2;
gradients = dlgradient(loss,dlnet.Learnables);

end

%% Mini-Batch Preprocessing Function

function [X1,X2,angle] = preprocessData(X1Cell,X2Cell,angleCell)
    
    X1 = cat(1,X1Cell{:});
    X2 = cat(1,X2Cell{:});
    angle = cat(2,angleCell{:});
        

end


