function [dimaterouterequivalant,t0picked]=getPhysiceShape(D,t,ratio)
bilayerDimaterouter=D;
bilayerthickness=t;
bilayerthicknessratio=ratio;

for num=1
    
E1=120000;
E2=69000;
lambda2=E1/E2;   %%%%% E1/E2



Dimaterouter=bilayerDimaterouter(num);  %%dimater outer
radiusouter=Dimaterouter/2;
thickness=bilayerthickness(num);   %%
thicknessratio=bilayerthicknessratio(num);
outerthickness=(thicknessratio*thickness)/(thicknessratio+1);
innerthickness=(thickness)/(thicknessratio+1);

junctionradius=radiusouter-outerthickness;

t1=outerthickness;
t2=innerthickness;
r=junctionradius;


% num


% cc=t1-offsetdistance
ccc=(t1*t1+2*lambda2*t1*t2+t2*t2*lambda2)/(2*t1+2*lambda2*t2);%the distance between the central axis and the upper edge of the micro-element
if ccc<t1
    offsetdistance=t1-ccc;
    R=junctionradius+offsetdistance;%%%%junctionradius after equivalent
else
%      num
    offsetdistance=ccc-t1;
    R=junctionradius-offsetdistance;
end



% R=junctionradius+offsetdistance;%%%%Ejunctionradius


f2=(-1/R)*(((r+t1)^4)-(1-lambda2)*(r^4)-lambda2*((r-t2)^4));%%%
f3=(-1/R)*((r+t1)^4-r^4+(r-0.5*t2*(1-lambda2))^4-(r-0.5*t2*(1+lambda2))^4);
% syms t0 
% % solve('t0^3+4*R*R*t0-f2','t0')
% solve('t0^3+t0^2+t0')
a=1;
b=4*R*R;
c=0;
d=f3;
t0 = Solve3Polynomial(a, b, c, d);



for ii=1:3
   reallistnum(ii)=isreal(t0(ii));
end

reallistlocation=find(reallistnum==1);
reallistt0=t0(reallistlocation);

positivenumberlocation=find(reallistt0>0);
t0picked(num,:)=reallistt0(positivenumberlocation);


radiusouterequivalant=R+t0picked(num);
dimaterouterequivalant(num,:)=2*radiusouterequivalant;

end

end