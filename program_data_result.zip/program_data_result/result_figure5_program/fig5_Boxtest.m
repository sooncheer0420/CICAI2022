
clc
clear all
close all


BLNET=load('result\BLNET.mat');
BPNET=load('result\BPNET.mat');
PENET=load('result\PENET.mat');
PENETWMA=load('result\PENETWMA.mat');
PENETWSP=load('result\PENETWSK.mat');

PENET_RMSE=PENET.angleRMSE';
PENETWMA_RMSE=PENETWMA.angleRMSE';
PENETWSP_RMSE=PENETWSP.angleRMSE';
BLNET_RMSE=BLNET.angleRMSE';
BPNET_RMSE=BPNET.angleRMSE';

rng default  % For reproducibility
x = [PENET_RMSE PENETWMA_RMSE PENETWSP_RMSE BLNET_RMSE BPNET_RMSE];
% x = [PENET_RMSE PENETWMA_RMSE ];
figure('color',[1 1 1]);
h=boxplot(x);
set(h,'LineWidth',1.3);  
grid on
hold on;
set(gca,'xticklabels',{'PE-NET','PE-NET-WMA','PE-NET-WSP','BL-NET','BP-NET'});
ylabel('\fontname{Times New Roman}RMSE')
set(gca,'position',[0.25 0.1 0.5 0.8]);
set(gca,'FontSize',17,'Fontname', 'Times New Roman');


axes('Position',[0.251,0.135,0.20,0.34]); 

x2 = [PENET_RMSE PENETWMA_RMSE ];
h2=boxplot(x2);
set(h2,'LineWidth',1.3);   
set(gca,'xticklabels',{'',''});
% axis square
set(gca,'ytick',0:0.2:1.4)
set(gca,'FontSize',15,'Fontname', 'Times New Roman');
set(gca,'YAxisLocation','right'); 
grid on